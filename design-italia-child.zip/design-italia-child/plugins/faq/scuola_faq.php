<?php
/**
 * Plugin Name: SiSviluppo_FAQ
 * Plugin URI:
 * Description: Plugin per la gestione di FAQs
 *
 * Version: 0.1
 *
 * License: GNU General Public License v2.0
 * License URI: http://www.opensource.org/licenses/gpl-license.php
 */

class ScuolaFAQ {

     // Plugin version => 0.1.

 
    /**
     * Initialize the class and set its properties.
     *
     * @since   1.6.0
     */
    public function __construct() {
        $this->load_dependencies();

    }
	function faq_add_descrizione_titolo($post) {
		if($post->post_type == "faq"){
			_e('<span><i>il <strong>Titolo</strong> &egrave; la <strong>domanda della FAQ</strong>.<br>', 'wpscuola' );
			_e('<h2>Risposta alla domanda della FAQ</h2>', 'wpscuola' );
		}
	}
   function CreaCustoms() {
   	
   		$labels = array(
		'name'                  => _x( 'FAQs', 'Post Type General Name', 'wpscuola' ),
		'singular_name'         => _x( 'FAQ', 'Post Type Singular Name', 'wpscuola' ),
		'menu_name'             => __( 'FAQs', 'wpscuola' ),
		'name_admin_bar'        => __( 'FAQs', 'wpscuola' ),
		'archives'              => __( 'Archivio FAQ', 'wpscuola' ),
		'attributes'            => __( 'Attributi FAQ', 'wpscuola' ),
		'parent_item_colon'     => __( 'FAQ Padre:', 'wpscuola' ),
		'all_items'             => __( 'Tutte le FAQs', 'wpscuola' ),
		'add_new_item'          => __( 'Aggiungi nuova FAQ', 'wpscuola' ),
		'add_new'               => __( 'Aggiungi Nuova', 'wpscuola' ),
		'new_item'              => __( 'Nuova FAQ', 'wpscuola' ),
		'edit_item'             => __( 'Modifica FAQ', 'wpscuola' ),
		'update_item'           => __( 'Aggiorna FAQ', 'wpscuola' ),
		'view_item'             => __( 'Visualizza FAQ', 'wpscuola' ),
		'view_items'            => __( 'Visualizza FAQs', 'wpscuola' ),
		'search_items'          => __( 'Cerca FAQ', 'wpscuola' ),
		'not_found'             => __( 'FAQ non trovata', 'wpscuola' ),
		'not_found_in_trash'    => __( 'FAQ non trovato nel cestino', 'wpscuola' ),
		'items_list'            => __( 'Lista FAQs', 'wpscuola' ),
		'items_list_navigation' => __( 'Naviga la Lista delle FAQs', 'wpscuola' ),
		'filter_items_list'     => __( 'Filtra lista FAQs', 'wpscuola' ),
	);
	$args = array(
		'label'                 => __( 'FAQ', 'wpscuola' ),
		'description'           => __( "Frequently asked questions (FAQ), alias Le domande più frequenti.", 'wpscuola' ),
		'labels'                => $labels,
		'supports'              => false,
//		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 21,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
		'show_in_rest' => true,
		'supports'          	=> array( 'title', 'editor', 'revisions', 'page-attributes' ),
	);
	register_post_type( 'faq', $args );
 
       register_taxonomy('group','faq',
       			array(
       			'labels'                     =>array(
	                        'name'                          => 'Gruppi',
	                        'singular_name'                 => 'Gruppo',
	                        'search_items'                  => 'Cerca Gruppi',
	                        'popular_items'                 => 'Gruppi popolari',
	                        'all_items'                     => 'Tutti i Gruppi',
	                        'parent_item'                   => null,
	                        'parent_item_colon'             => null,
	                        'edit_item'                     => 'Modifica Groupo',
	                        'update_item'                   => 'Aggiorna Groupo',
	                        'add_new_item'                  => 'Aggiungi un Nuovo Groupo',
	                        'new_item_name'                 => 'Nome nuovo Gruppo',
	                        'separate_items_with_commas'    => 'Separare i Gruppi con le virgole',
	                        'add_or_remove_items'           => 'Aggiungi o Rimuovi Gruppi',
	                        'choose_from_most_used'         => 'Seleziona dai Gruppi più usati',
	                        'menu_name'                     => 'Gruppi',
	                    ),
                    'hierarchical'              => true,
                    'show_ui'                   => true,
                    'update_count_callback'     => '_update_post_term_count',
                    'query_var'                 => true,
                    'rewrite'                   => array( 'with_front' => false )
                )
            );
	}

    function messages( $messages ) {
        global $post, $post_ID;
        $post_type = get_post_type( $post_ID );

        $obj = get_post_type_object( $post_type );
        $singular = $obj->labels->singular_name;

        $messages[$post_type] = array(
            0  => '', // Unused. Messages start at index 1.
            1  => sprintf($singular . ' aggiornato. <a href="%s">Visualizza ' . strtolower( $singular ) . '</a>', esc_url( get_permalink( $post_ID ) ) ),
            2  =>'Campo personalizzato Aggiornato',
            3  =>'Campo personalizzato cancellato',
            4  =>$singular . ' aggiornato.',
            5  => isset($_GET['revision'] ) ? sprintf( ' recuperato dalla revisione da %s', wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
            6  => sprintf($singular . ' pubblicato. <a href="%s">Visualizza ' . strtolower( $singular ) . '</a>', esc_url( get_permalink( $post_ID ) ) ),
            7  => 'Pagina salvata.',
            8  => sprintf($singular . ' inviata. <a target="_blank" href="%s">Anteprima ' . strtolower( $singular ) . '</a>', esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
            9  => sprintf($singular . ' schedulato per: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Anteprima ' . strtolower( $singular ) . '</a>', date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ) ),
            10 => sprintf($singular . ' elemento aggiornato. <a target="_blank" href="%s">Anteprima ' . strtolower( $singular ) . '</a>', esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
        );

        return $messages;
    }

    function Colonne_FAQ_Intestazioni( $columns ) {
		if (get_post_type()=="faq"){
	        $columns = array(
	            "cb"          => '<input type="checkbox" />',
	            "title"      => 'Titolo FAQ',
	            "contenuto"   => 'Risposta',
	            'gruppo'      => 'Gruppi', 
	            'shortcode'   => 'Shortcode', 
	            "date"        => 'Data', 
	        );
		}
        return $columns;
    }
    function Colonne_FAQ_Contenuti( $defaults ) {
        global $post;
		if (get_post_type()=="faq"){
	        switch( $defaults ) {
	            case "contenuto":
	                the_excerpt();
	                break;
	            case "gruppo":
	                echo get_the_term_list( $post->ID, 'group', '', ', ', '' );
	                break;
	            case "shortcode":
	                printf( '[faq p=%d]', get_the_ID() );
	                break;
	            default:
	                break;
	        }
	    }
    }
    private function load_dependencies() {
    	add_action( 'init',  									array( $this, 'CreaCustoms' ) );
    	add_action( 'edit_form_after_title', 					array( $this,'faq_add_descrizione_titolo' ) );
 		add_filter( 'enter_title_here', 						array( $this,'faq_change_title_text' ) );
        add_filter( 'manage_posts_columns',     				array( $this, 'Colonne_FAQ_Intestazioni' ) );
        add_action( 'manage_posts_custom_column',   			array( $this, 'Colonne_FAQ_Contenuti' ) );
        add_filter( 'post_updated_messages',    				array( $this, 'messages' ) );
        add_filter( 'post_updated_messages',       				array( $this, 'messages' ) );
		add_action( 'admin_menu', 								array( $this, 'add_faq_metabox' ) );
        add_shortcode( 'FAQ',                       			array( $this, 'visualizza_faq' ) );
     }
    private function return_to_top( $link ) {
        $html = '';

        // Grab our metadata
        $rtt = get_post_meta( get_the_id(), '_acf_rtt', true );

        // If Return to Top checkbox is true
        if ( $rtt && $link ) {
             $html .= '<div class="faq-to-top"><a href="#' . $link . '">Torna all\'inizio</a></div>';
        }
        return $html;
    }
    public function visualizza_faq( $args) {
        // Merge incoming args with the class defaults
        $args = wp_parse_args( $args, array(
            'order'             => 'ASC',
            'orderby'           => 'title',
            'posts_per_page'    => -1,
            'gruppi'           => '') );
        $html = '<div id="collapseDivFAQ" class="collapse-div collapse-background-active" role="tablist">';
        $terms = get_terms( 'group' );
        $gruppi = $args['gruppi'];
        $gruppi=explode(",",str_replace(' ', '', $gruppi));
        if ( ! empty( $terms ) ) {
            foreach ( $terms as $term ) {
                if (in_array($term->slug, $gruppi) ){
	                $query_args = array(
	                    'post_type'         => 'faq',
	                    'order'             => $args['order'],
	                    'orderby'           => $args['orderby'],
	                    'posts_per_page'    => $args['posts_per_page'],
	                    'tax_query'         => array(
	                        array(
	                            'taxonomy'  => 'group',
	                            'field'     => 'slug',
	                            'terms'     => array( $term->slug ),
	                            'operator'  => 'IN'
	                        )
	                    )
	                );
	                // New query just for the tax term we're looping through
	                $q = new WP_Query( $query_args );
	               // echo $q->request;
	                if ( $q->have_posts() ) {
	                    $html .= '  <div class="collapse-header" id="heading' . $term->term_id . '">
    <button data-toggle="collapse" data-target="#collapse' . $term->term_id . '" aria-expanded="false" aria-controls="collapse' . $term->term_id . '">' . $term->name . '</button>';
 	                    // If the term has a description, show it
	                    if ( $term->description )
	                        $html .= '<p>' . $term->description . '</p>';
 						$html .= '</div> 
 	<div id="collapse' . $term->term_id . '" class="collapse " role="tabpanel" aria-labelledby="heading' . $term->term_id . '">
    	<div class="collapse-body">';
	                    while ( $q->have_posts() ) : $q->the_post();
							$html .='    	     
	    	<div id="collapseDiv' . $term->term_id . '" class="collapse-div" role="tablist">
				<div class="collapse-header" id="headingInt'. get_the_ID().'">
          			<button data-toggle="collapse" data-target="#collapseVoce'. get_the_ID().'" aria-expanded="false" aria-controls="collapseVoce'. get_the_ID().'">'.get_the_title().'</button>
        		</div>
		        <div id="collapseVoce'. get_the_ID().'" class="collapse " role="tabpanel" aria-labelledby="headingInt'. get_the_ID().'">
		    		<div class="collapse-body">' . apply_filters( 'the_content', get_the_content() ).' </div>
		        </div>
		    </div>';
	                    endwhile;
                        $html .= '
        </div>
	</div>';
	                } // end have_posts()
	                wp_reset_postdata();
	            } // end foreach
	        }
        } 
        return $html;
    }
    public function add_faq_metabox() {		
	    add_meta_box( 'faq-box-shortcode', 'Shortcode FAQ', 	array( $this, 'faq_box_shortcode' ), 'faq', 'side' );
	}
    public function faq_box_shortcode() {
        global $post_ID;
        ?>
        <p class="howto">
            <?php echo 'Per visualizzare questa domanda, bisogna copiare il codice di seguito riportato ed incollarlo in un post, pagina o nell\'area testo di un Widget Testo'; ?>
        </p>
        <p><input type="text" value="[faq p=<?php echo $post_ID; ?>]" readonly="readonly" class="widefat wp-ui-text-highlight code"></p>
        <?php
    }
	function faq_change_title_text( $title ){
	     $screen = get_current_screen();
	  
	     if  ( 'faq' == $screen->post_type ) {
	          $title = __('Inserisci la Domanda della FAQ', 'wpscuola' );
	     }
	  
	     return $title;
	}

}